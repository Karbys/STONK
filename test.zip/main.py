import plotly.graph_objects as go

# สร้างข้อมูลตัวอย่าง
x = [1, 2, 3, 4, 5]
y = [1, 4, 9, 16, 25]

# สร้างกราฟ
fig = go.Figure()

# เพิ่มเส้นกราฟ
fig.add_trace(go.Scatter(x=x, y=y, mode='lines+markers', name='Example Line'))

# ตั้งค่าชื่อกราฟและแกน
fig.update_layout(
    title='Interactive Plot Example',
    xaxis_title='X Axis',
    yaxis_title='Y Axis'
)

# บันทึกกราฟเป็นไฟล์ HTML
fig.write_html('asset/graph/interactive_plot.html')
