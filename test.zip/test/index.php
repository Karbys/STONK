<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Plot with Plotly</title>
</head>
<body>
    <h1>Interactive Plot from Python</h1>
    <a href="../">Back</a>
    <!-- ฝังไฟล์ HTML ที่สร้างจาก Python -->
    <iframe src="../asset/graph/raw_data_plot.html" width="100%" height="600px"></iframe>
    <iframe src="../asset/graph/forecast_plot.html" width="100%" height="600px"></iframe>
</body>
</html>
